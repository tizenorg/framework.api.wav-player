/*
 * Copyright (c) 2011 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */


#ifndef __TIZEN_MEDIA_WAV_PLAYER_DOC_H__
#define __TIZEN_MEDIA_WAV_PLAYER_DOC_H__


/**
 * @file wave_player_doc.h
 * @brief File contains the high level documentation for the WAV Player API.
 *
 */

/**
 * @defgroup CAPI_MEDIA_WAV_PLAYER_MODULE WAV Player
 * @ingroup CAPI_MEDIA_FRAMEWORK
 */

/**
 * @addtogroup CAPI_MEDIA_WAV_PLAYER_MODULE
 * @brief The @ref CAPI_MEDIA_WAV_PLAYER_MODULE API  provides functions for playing the Waveform Audio File Format. (*.wav)
 * @ingroup CAPI_MEDIA_FRAMEWORK
  * @section CAPI_MEDIA_WAV_PLAYER_MODULE_HEADER Required Header
 *    \#include <wav_player.h>
 *
 * @section CAPI_MEDIA_WAV_PLAYER_OVERVIEW Overview
 * The @ref CAPI_MEDIA_WAV_PLAYER_MODULE API allows you to simply play and stop a wav file. To play a certain wav file, call wave_player_start() with a path to the .wav file. When playing a wav file is finished, wav_player_playback_completed_cb() will be invoked.
 */

#endif /* __TIZEN_MEDIA_WAV_PLAYER_DOC_H__ */


